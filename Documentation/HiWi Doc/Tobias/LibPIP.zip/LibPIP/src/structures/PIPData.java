package structures;

public class PIPData {
	/** uniquely identifies a data item */
	public int identifier;

	/** the actual information/data */
	public Object content;
	
	
}
